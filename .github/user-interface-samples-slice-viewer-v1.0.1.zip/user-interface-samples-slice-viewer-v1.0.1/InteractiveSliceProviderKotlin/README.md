Android Interactive Slice Provider
=====================

This application demonstrates building Android Slices.
