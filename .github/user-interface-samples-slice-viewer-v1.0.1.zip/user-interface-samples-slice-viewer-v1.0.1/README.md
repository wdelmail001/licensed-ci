Android User Interface Samples Repository
=========================================

This repository contains a set of individual Android Studio projects to help you get
started writing/understanding Android user interface features.
