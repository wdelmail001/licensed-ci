# Android on Chrome OS - Drag and Drop Demo

## This is not an official Google product

A demo android application demonstrating basic Drag and Drop functionality
with Chrome OS in mind.

Allows for plain-text items and files from the Chrome OS file manager to be
dragged into the app. Has a plain-text item that can be dragged out.

For reference and education only.
