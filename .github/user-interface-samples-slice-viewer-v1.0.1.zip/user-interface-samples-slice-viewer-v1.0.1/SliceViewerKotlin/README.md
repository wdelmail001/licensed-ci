Android Slice Viewer
=====================

This application allows testing the embedding behavior of Android Slices inside
other applications.
